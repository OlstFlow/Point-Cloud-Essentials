from .core import bl_info, register, unregister
